<template>
  <nav-bar></nav-bar>
</template>
<script setup>
import navBar from "@/components/navBar/index.vue";
import { useRouter } from "vue-router";

const router = useRouter();
</script>
