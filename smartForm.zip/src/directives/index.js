import setupClickOutside from "./setupClickOutside";

/** 自定义vue指令 */
export function setupDirectives(app) {
  setupClickOutside(app);
}
