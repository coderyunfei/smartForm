<template>
  <router-view></router-view>
</template>

<script setup>
// This starter template is using Vue 3 experimental <script setup> SFCs
// Check out https://github.com/vuejs/rfcs/blob/script-setup-2/active-rfcs/0000-script-setup.md
</script>

<style lang="scss">
#app {
  height: 100%;
  width: 100%;
}
html,
body {
  width: 100%;
  height: 100%;
  background-color: #f9f9f9;
}
</style>
