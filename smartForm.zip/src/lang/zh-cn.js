export default {
  user: {
    name: "smartForm",
    changeLang: "切换语言",
  },
  home: {
    toabout: "去介绍",
  },
  about: {
    toHome: "去首页",
  },
};
