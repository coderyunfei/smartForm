export default {
  user: {
    name: "smart Form",
    changeLang: "Change Language",
  },
  home: {
    toLogin: "To Login",
  },
  login: {
    toHome: "To Home",
  },
};
